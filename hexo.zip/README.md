# hexo
hexo静态资源仓，文章更新放这里


1，在别的电脑上安装hexo   https://weibsgz.github.io/2017/07/15/hexo/  至可以跑出一个新的hexo主页

2，拷贝此仓库下的文件至你的新hexo文件夹下覆盖  

3，注意主题文件夹下 next主题为空，需要先安装，然后设置主题下的配置文件（sidebar，avatar）
