---
layout: post
title:  css sprite工具
date:   2015-12-27 01:08:00 +0800
categories: 工具
tag: 工具
---


此软件简单易用，同事提供，感谢  [css sprite](https://github.com/weibsgz/LessOrMore/blob/gh-pages/libs/CssSprite.exe)



