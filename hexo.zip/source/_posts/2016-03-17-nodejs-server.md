---
layout: post
title:  如何使用nodejs快速搭建本地服务器
date:   2016-3-17 01:08:00 +0800
categories: 工具
tag: 工具
---


用anywhere快速搭建本地服务器
```
npm install anywhere -g
```
之后找到你想搭建服务器的路径，然后再当前路径下输入：
```
anywhere 8860
```
然后浏览器就自动打开本地访问网址，一个简单的node服务器就这样被我们搭建好啦！
