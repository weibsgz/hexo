---
layout: post
title:  "css星级评价"
date:   2014-11-17 13:31:01 +0800
categories: css
tag: css
---




星级评价CSS
------------------------
```
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" />
    <title>sell</title>
    <style>
    .chStar {
        height: 14px;
        width: 73px;
        background-image: url(./chStar.png);
        display: inline-block;
        overflow: hidden;
    }
    
    .chStar01 {
        background-position: 0 0;
    }
    
    .chStar02 {
        background-position: 0 -20px;
    }

    .chStar03 {
        background-position: 0 -40px;
    }
    
    .chStar04 {
        background-position: 0 -60px;
    }
    
    .chStar05 {
        background-position: 0 -80px;
    }
    
    .chStar06 {
        background-position: 0 -100px;
    }
    
    .chStar07 {
        background-position: 0 -120px;
    }
    
    .chStar08 {
        background-position: 0 -140px;
    }
    
    .chStar09 {
        background-position: 0 -160px;
    }
    
    .chStar10 {
        background-position: 0 -180px;
    }
    </style>
</head>

<body>
    <div class="chStar chStar03"></div>
</body>

</html>



```



![百度](/uploads/chStar.png)

