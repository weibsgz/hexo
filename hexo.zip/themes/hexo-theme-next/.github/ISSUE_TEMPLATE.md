## ATTENTION!
If you want to fast resolve your issue, **write it in English, please**. Not all contributors/collaborators know Chinese language and Google translate can't always give true translates on issues. Thanks!

***

### Expected behavior (预期行为)


### Actual behavior (实际行为)


### Steps to reproduce the behavior (重现步骤)


### NexT Information

Add the  ✔  sign before an item which is affected by this behavior.

NexT Version:

  -  Master
  -  Latest Release
  -  Old version - 

NexT Scheme:
  -  All schemes
  -  Muse
  -  Mist
  -  Pisces

### Other Information (Like Browser, System, Screenshots)


